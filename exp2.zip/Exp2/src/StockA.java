
public class StockA extends Stock {
	private int price1;
	
	public void Change(int price1) {
		this.price1=price1;
		this.NotifyObservers();
	}
	
	
	
    public void NotifyObservers() {
		for(Users users:users1) {
			users.update(price1);
		}
	}



	@Override
	public void update(int price) {
		// TODO Auto-generated method stub
		
	}



	

}
	