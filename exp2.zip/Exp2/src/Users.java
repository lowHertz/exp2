
public interface Users {

	public void update(int price);

	
}
