import java.util.ArrayList;

public abstract class  Stock implements Users {
       protected ArrayList<Users> users1;
       
       public Stock() {
    	   users1 = new ArrayList<Users>();
       }
       public void RegisterObserver(Users users) {
    	   users1.add(users);
       }
       public void RemoveObservers(Users users) {
    	   users1.remove(users);
       }
       public abstract void  NotifyObservers();
	
	
	
    	        
}
