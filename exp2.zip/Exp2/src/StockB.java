public class StockB extends Stock {
	private int price2;
	
	public void Change(int price2) {
		this.price2=price2;
		this.NotifyObservers();
	}
	
	
	
    public void NotifyObservers() {
		for(Users users:users1) {
			users.update(price2);
		}
	}



	@Override
	public void update(int price) {
		// TODO Auto-generated method stub
		
	}



	



	

}
	