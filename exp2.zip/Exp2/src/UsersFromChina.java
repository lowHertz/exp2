
public class UsersFromChina implements Users {

		public void update(int price) {
			System.out.println("Message for China StockA Price="+ price);
			System.out.println("Message for China StockB Price="+ price);
		}
		
		

		
}
