
public class Test {
	
	public static void main(String[] args) {
		StockA stocka = new StockA();
		StockB stockb = new StockB();
		
		UsersFromRussian usersfromrussian = new UsersFromRussian();
		UsersFromChina usersfromchina = new UsersFromChina();
		
		
		stocka.RegisterObserver(usersfromchina);		
		stockb.RegisterObserver(usersfromrussian);
		
		stocka.Change(92);
		stockb.Change(92);
		
		
	}

}
